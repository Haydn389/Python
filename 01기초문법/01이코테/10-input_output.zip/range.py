import sys

data=sys.stdin.readline().strip()

print(len(data))

for i in range(len(data)):
  print(i)

for i in range(len(data)):
  print(data[i])
