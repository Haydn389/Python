import sys
n = int(input())
s= input()
print(n*s)
print("======")
n = int(sys.stdin.readline())
a= sys.stdin.readline()
print(n*a)
