import sys
data=[]
n,m=map(int,sys.stdin.readline().split())
data=[[0]*m for _ in range(n)]
print(data)

