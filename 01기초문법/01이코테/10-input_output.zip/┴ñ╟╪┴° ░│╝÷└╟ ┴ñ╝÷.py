import sys
n,m = map(int,sys.stdin.readline().split(" "))

print(n,m)