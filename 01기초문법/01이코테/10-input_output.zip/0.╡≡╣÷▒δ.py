a=3
b=4

def hap(a1,b1):
    c=a1+b1
    return c

ret=hap(a,b)
print(ret)
